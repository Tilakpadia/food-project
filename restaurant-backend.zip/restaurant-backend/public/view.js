function goBack() {
  window.location.href = "foodForm.html";
}

document.addEventListener("DOMContentLoaded", () => {
  const foodGrid = document.getElementById("foodGrid");

  fetch("http://localhost:3000/api/foods")
    .then(res => res.json())
    .then(foodItems => {
      if (!foodItems || foodItems.length === 0) {
        foodGrid.innerHTML = "<p>No food items found. Please add some!</p>";
        return;
      }

      foodGrid.innerHTML = "";
      foodItems.forEach((item) => {
        const card = document.createElement("div");
        card.className = "food-card";

        // Use uploaded image (Base64) or fallback
        const imgUrl = item.image || "https://source.unsplash.com/400x300/?food";

        card.innerHTML = `
          <img src="${imgUrl}" alt="Food Image">
          <div class="info">
            <span class="badge ${item.category}">${item.category}</span>
            <h4>${item.name} <span>₹${item.price}</span></h4>
            <p>${item.description || "No description provided"}</p>
            <div class="card-actions">
              <button class="btn edit-btn" onclick="editFood(${item.id})">✏️ Edit</button>
              <button class="btn delete-btn" onclick="deleteFood(${item.id})">🗑️ Delete</button>
            </div>
          </div>
        `;
        foodGrid.appendChild(card);
      });
    })
    .catch(err => console.error("Error:", err));
});

// Delete
function deleteFood(id) {
  fetch(`http://localhost:3000/api/foods/${id}`, { method: "DELETE" })
    .then(() => window.location.reload())
    .catch(err => console.error("Error:", err));
}

// Edit
function editFood(id) {
  localStorage.setItem("editFoodId", id);
  window.location.href = "foodForm.html";
}
