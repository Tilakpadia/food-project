const mysql = require("mysql2");

// Create connection to MySQL
const db = mysql.createConnection({
  host: "localhost",   // database server
  user: "root",        // your MySQL username (default is "root")
  password: "10599Omi",        // your MySQL password (leave empty if none)
  database: "restaurant_db" // database name
});

// Connect and log status
db.connect(err => {
  if (err) {
    console.error(" MySQL connection failed:", err.message);
    process.exit(1); // stop server if DB not connected
  }
  console.log("MySQL connected to database 'restaurant_db'");
});

module.exports = db;

