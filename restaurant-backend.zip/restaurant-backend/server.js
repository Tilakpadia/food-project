const express = require("express");
const path = require("path");
const db = require("./db");

const app = express();
app.use(express.json());

// 🔹 Serve static files (frontend)
app.use(express.static(path.join(__dirname, "public")));

// ✅ Get all foods
app.get("/api/foods", (req, res) => {
  db.query("SELECT * FROM foods", (err, results) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(results);
  });
});

// ✅ Add new food
app.post("/api/foods", (req, res) => {
  const { name, price, category, description, image } = req.body;
  const sql = "INSERT INTO foods (name, price, category, description, image) VALUES (?, ?, ?, ?, ?)";
  db.query(sql, [name, price, category, description, image], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json({ id: result.insertId, name, price, category, description, image });
  });
});

// ✅ Update food
app.put("/api/foods/:id", (req, res) => {
  const { id } = req.params;
  const { name, price, category, description, image } = req.body;
  const sql = "UPDATE foods SET name=?, price=?, category=?, description=?, image=? WHERE id=?";
  db.query(sql, [name, price, category, description, image, id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ id, name, price, category, description, image });
  });
});

// ✅ Delete food
app.delete("/api/foods/:id", (req, res) => {
  const { id } = req.params;
  const sql = "DELETE FROM foods WHERE id=?";
  db.query(sql, [id], (err, result) => {
    if (err) return res.status(500).json({ error: err.message });
    res.status(204).end();
  });
});

// Default route → menu page
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "foodList.html"));
});

app.listen(3000, () => {
  console.log("🚀 Server running at http://localhost:3000");
});
