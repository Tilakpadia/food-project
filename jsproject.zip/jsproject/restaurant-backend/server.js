// server.js
const express = require("express");
const path = require("path");
const app = express();



// ✅ Increase JSON & URL-encoded body size limit 
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ limit: "10mb", extended: true }));

// 🔹 Serve static files from /public
app.use(express.static(path.join(__dirname, "public")));

// In-memory DB (⚠️ resets on restart)
let foodItems = [];

// ✅ Get all foods
app.get("/api/foods", (req, res) => {
  res.json(foodItems);
});

// ✅ Add new food
app.post("/api/foods", (req, res) => {
  const { name, price, category, description, image } = req.body;

  if (!name || !price || !category) {
    return res.status(400).json({ error: "Name, price, and category are required." });
  }

  const newFood = {
    id: Date.now(),
    name,
    price,
    category,
    description,
    image
  };

  foodItems.push(newFood);
  res.status(201).json(newFood);
});

// ✅ Update food
app.put("/api/foods/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const index = foodItems.findIndex(f => f.id === id);

  if (index === -1) {
    return res.status(404).json({ error: "Food item not found" });
  }

  foodItems[index] = { id, ...req.body };
  res.json(foodItems[index]);
});

// ✅ Delete food
app.delete("/api/foods/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const before = foodItems.length;
  foodItems = foodItems.filter(f => f.id !== id);

  if (foodItems.length === before) {
    return res.status(404).json({ error: "Food item not found" });
  }

  res.status(204).end();
});

// ✅ Default route → open menu page
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "foodList.html"));
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
