// let foodItems = [];

// document.addEventListener("DOMContentLoaded", () => {
//   const form = document.getElementById("foodForm");
//   const savedItems = localStorage.getItem("foodItems");
//   if (savedItems) {
//     foodItems = JSON.parse(savedItems);
//   }

//   form.addEventListener("submit", function (e) {
//     e.preventDefault();

//     const name = document.getElementById("name").value.trim();
//     const price = parseFloat(document.getElementById("price").value);
//     const category = document.getElementById("category").value;
//     const description = document.getElementById("description").value.trim();
//     const imageInput = document.getElementById("image");

//     if (!name || isNaN(price) || price <= 0 || !category) {
//       alert("⚠️ Please fill in all required fields correctly.");
//       return;
//     }

//     // Handle image upload (convert to Base64)
//     if (imageInput.files && imageInput.files[0]) {
//       const reader = new FileReader();
//       reader.onload = function (event) {
//         saveFood(name, price, category, description, event.target.result);
//       };
//       reader.readAsDataURL(imageInput.files[0]);
//     } else {
//       // No image uploaded → fallback
//       saveFood(name, price, category, description, null);
//     }
//   });
// });

// function saveFood(name, price, category, description, image) {
//   const food = { name, price, category, description, image };

//   foodItems.push(food);
//   localStorage.setItem("foodItems", JSON.stringify(foodItems));

//   // Redirect to food list page
//   window.location.href = "foodList.html";
// }
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("foodForm");
  const editId = localStorage.getItem("editFoodId");

  // If editing → load data from server and prefill form
  if (editId) {
    fetch("http://localhost:3000/api/foods")
      .then(res => res.json())
      .then(foodItems => {
        const item = foodItems.find(f => f.id == editId);
        if (item) {
          document.getElementById("name").value = item.name;
          document.getElementById("price").value = item.price;
          document.getElementById("category").value = item.category;
          document.getElementById("description").value = item.description;
        }
      });
  }

  // Submit form
  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("name").value.trim();
    const price = parseFloat(document.getElementById("price").value);
    const category = document.getElementById("category").value;
    const description = document.getElementById("description").value.trim();
    const imageInput = document.getElementById("image");

    if (!name || isNaN(price) || price <= 0 || !category) {
      alert("⚠️ Please fill in all required fields correctly.");
      return;
    }

    // Handle image upload (convert to Base64 like old code)
    if (imageInput.files && imageInput.files[0]) {
      const reader = new FileReader();
      reader.onload = function (event) {
        saveFood(name, price, category, description, event.target.result);
      };
      reader.readAsDataURL(imageInput.files[0]);
    } else {
      // No image uploaded → send empty string
      saveFood(name, price, category, description, "");
    }
  });
});

// 🔹 Save or update food to server
function saveFood(name, price, category, description, image) {
  const food = { name, price, category, description, image };
  const editId = localStorage.getItem("editFoodId");

  if (editId) {
    // Update
    fetch(`http://localhost:3000/api/foods/${editId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(food)
    })
      .then(() => {
        localStorage.removeItem("editFoodId");
        window.location.href = "foodList.html";
      });
  } else {
    // Add
    fetch("http://localhost:3000/api/foods", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(food)
    })
      .then(() => {
        window.location.href = "foodList.html";
      })
      .catch(err => console.error("Error:", err));
  }
}
